## Install
 - clone this repo
 - `pip install -r requirements.txt`

## Run
` python app.py`

## Todo
 - PIP module
 - Include other services
 - Reference files(eg: config.yml)
   - Fase 1 OK. Cloudfront, WAF and Route53 prompt. Need improvement in docs
 - Validar no cloudshell(permissoes, etc)
   - OK, precisa de ajuste na questao de regioes.

## Config References:
https://docs.aws.amazon.com/config/latest/developerguide/resource-config-reference.html


"To track configuration changes to your CloudFront distribution, you must log in to the AWS Console in the US East (N. Virginia) public region."